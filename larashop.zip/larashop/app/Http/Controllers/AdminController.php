<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect; 
use App\Http\Requests;
use DB;
use Session;
Session_start();


class AdminController extends Controller
{
     public function index()
    {
    	return view('admin_login');

    }


    //   public function show_dashboard()
    // {
    // 	return view('admin.dashboard');

    // }


     public function dashboard(Request $request)
    {
    	//return view('admin.dashboard');
	    $admin_email=$request->admin_email;
	   $admin_password=md5($request->admin_password);
	   $result=DB::table('tb1_admin')
	  ->where('admin_email',$admin_email)
	  ->where('admin_password',$admin_password)
	  ->first();
	 //echo "</pre>";
		 //print_r($result);

	   if($result){
	   	Session::put('admin_name',$result->admin_name);
	   	Session::put('admin_id',$result->admin_id);
	    return Redirect::to('/dashboard');
	    

	    }
	   else{
	    	Session::put('message','Email or Password Invalid');
	    	return Redirect::to('/admin');

   		 }
	

    }


      public function manage_order()
    {
    		$all_order_info=DB::table('tbl_order')
   					->join('tbl_customer','tbl_order.customer_id','=','tbl_customer.customer_id')
   					->select('tbl_order.*','tbl_customer.customer_name')
   					->get();
   			$manage_order=view('admin.manage_order')
   					->with('all_order_info',$all_order_info);

   			return view('admin_layout')
   					->with('admin.manage_order',$manage_order);

    }


      public function view_order($order_id)
    {
    	    		$order_by_id=DB::table('tbl_order')
   					->join('tbl_customer','tbl_order.customer_id','=','tbl_customer.customer_id')
   					->join('tbl_order_details','tbl_order.order_id','=','tbl_order_details.order_id')
   					->join('tbl_shipping','tbl_order.shipping_id','=','tbl_shipping.shipping_id')
   					->select('tbl_order.*','tbl_order_details.*','tbl_shipping.*','tbl_customer.*')
   					->get();
   			$view_order=view('admin.view_order')
   					->with('order_by_id',$order_by_id);

   			return view('admin_layout')
   					->with('admin.view_order',$view_order);


    }



     public function Unactive($order_id)
   {
   		DB::table('tbl_order')
   			->where('order_id',$order_id)
   			->update(['order_status' => 'pending']);
   		Session::put('message','Order is not delivered yet !!');
   			return Redirect::to('/manage-order');
   }


    public function active($order_id)
   {
   		DB::table('tbl_order')
   			->where('order_id',$order_id)
   			->update(['order_status' => 'sucessfull']);
   		Session::put('message','Order is delivered sucessfully !!');
   			return Redirect::to('/manage-order');
   }



     public function delete_order($order_id)
   {
   		 DB::table('tbl_order')
   		->where('order_id',$order_id)
   		->delete();

   		Session::put('message','Order Deleted sucessfully !!');
		return Redirect::to('/manage-order');
   }

    
}
