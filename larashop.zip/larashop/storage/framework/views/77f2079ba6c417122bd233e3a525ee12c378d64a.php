<?php $__env->startSection('content'); ?>

<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-3 col-sm-offset-1">
					<div class="login-form"><!--login form-->

						<p class="alert-danger"> <?php 
			                    $message = Session::get('message');
			                    if($message)
			                    {
			                      echo $message;
			                      Session::put('message',null);
			                    }

			                    ?>
							</p>
						<h1>Thanks For your Order</h1>

						<p>We will call you soon......</p>

						
					</div><!--/login form-->
				</div>
				<div class="col-sm-1">
					<h2 class="or">OR</h2>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						
						
					</div><!--/sign up form-->
				</div>
			</div>
		</div>
	</section><!--/form-->


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>